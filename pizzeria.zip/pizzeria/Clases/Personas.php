<?php
require_once"AccesoDatos.php";
require_once 'JWT.php';
class Usuario
{
//--------------------------------------------------------------------------------//
//--ATRIBUTOS
	public $id;
	public $usuario;
 	public $contrasena;
  	public $tipo;
	public $local;
	public $estado;
//--------------------------------------------------------------------------------//
//--------------------------------------------------------------------------------//
//--GETTERS Y SETTERS
  	public function GetId()
	{
		return $this->id;
	}
	public function GetContra()
	{
		return $this->contrasena;
	}
	public function GetUsuario()
	{
		return $this->ususario;
	}
	public function GetTipo()
	{
		return $this->tipo;
	}
	public function GetLocal()
	{
		return $this->local;
	}
	public function GetEstado()
	{
		return $this->estado;
	}
	public function SetId($valor)
	{
		$this->id = $valor;
	}
	public function SetContra($valor)
	{
		$this->contrasena = $valor;
	}
	public function SetUsuario($valor)
	{
		$this->usuario = $valor;
	}
	public function SetTipo($valor)
	{
		$this->tipo = $valor;
	}
	public function SetLocal($valor)
	{
		$this->local = $valor;
	}
	public function SetEstado($valor)
	{
		$this->estado = $valor;
	}---------------------------------------------------------------------------//
//--CONSTRUCTOR
	public function __construct($dni=NULL)
	{
	}

//--METODO DE CLASE
	public static function login($usuario) 
	{	
		$objetoAccesoDato = AccesoDatos::dameUnObjetoAcceso(); 
		$consulta =$objetoAccesoDato->RetornarConsulta("select * from usuarios where usuario =:usuario and contrasena =:contrasena");
		$consulta->bindValue(':usuario', $usuario->usuario, PDO::PARAM_STR);
		$consulta->bindValue(':contrasena', $usuario->contrasena, PDO::PARAM_STR);
		$consulta->execute();
		$personaBuscada= $consulta->fetchObject('usuario');
		$token = new StdClass();
		$token->tok = AutentificadorJWT::CrearToken($personaBuscada);
		$token->id = $personaBuscada->id;
		$token->estado = $personaBuscada->estado;
		$token->tipo = $personaBuscada->tipo;
		return $token;					
	}
	
	public static function TraerTodos()
	{
		$objetoAccesoDato = AccesoDatos::dameUnObjetoAcceso(); 
		$consulta =$objetoAccesoDato->RetornarConsulta("select * from usuarios");
		$consulta->execute();			
		$arrPersonas= $consulta->fetchAll(PDO::FETCH_CLASS, "usuario");	
		return $arrPersonas;
	}
	
	public static function ActualizarUsuario($persona)
	{
			$objetoAccesoDato = AccesoDatos::dameUnObjetoAcceso(); 
			$consulta =$objetoAccesoDato->RetornarConsulta("
				update usuarios 
				set usuario=:usuario,
				contrasena=:contrasena,
				tipo=:tipo,
				local=:local,
				estado=:estado
				WHERE id=:id");
			$consulta->bindValue(':id',$persona->id, PDO::PARAM_INT);
			$consulta->bindValue(':usuario',$persona->usuario, PDO::PARAM_STR);
			$consulta->bindValue(':contrasena', $persona->contrasena, PDO::PARAM_STR);
			$consulta->bindValue(':tipo', $persona->tipo, PDO::PARAM_STR);
			$consulta->bindValue(':local', $persona->local, PDO::PARAM_STR);
			$consulta->bindValue(':estado', $persona->estado, PDO::PARAM_STR);
			return $consulta->execute();
	}

	public static function ActualizarEstado($persona)
	{
			$objetoAccesoDato = AccesoDatos::dameUnObjetoAcceso(); 
			$consulta =$objetoAccesoDato->RetornarConsulta("update usuarios set estado=:estado WHERE id=:id");

			$consulta->bindValue(':id',$persona->id, PDO::PARAM_INT);
			$consulta->bindValue(':estado',$persona->estado, PDO::PARAM_STR);
			return $consulta->execute();
	}
	public static function InsertarPersona($persona)
	{
		$objetoAccesoDato = AccesoDatos::dameUnObjetoAcceso(); 
		$consulta =$objetoAccesoDato->RetornarConsulta("INSERT into usuarios (usuario,contrasena,tipo,local,estado)values(:usuario,:contrasena,:tipo,:local,:estado)");
		$consulta->bindValue(':usuario',$persona->usuario, PDO::PARAM_STR);
		$consulta->bindValue(':contrasena', $persona->contrasena, PDO::PARAM_STR);
		$consulta->bindValue(':tipo', $persona->tipo, PDO::PARAM_STR);
		$consulta->bindValue(':local', $persona->local, PDO::PARAM_STR);
		$consulta->bindValue(':estado', 'activo', PDO::PARAM_STR);
		$consulta->execute();
		return $objetoAccesoDato->RetornarUltimoIdInsertado();
	}	
}