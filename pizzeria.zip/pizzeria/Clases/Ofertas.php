<?php
require_once"AccesoDatos.php";
class Ofertas
{
//--------------------------------------------------------------------------------//
//--ATRIBUTOS
	public $id;
	public $precio;
 	public $local;
  	public $limite;
	public $desc;
//--------------------------------------------------------------------------------//
//--------------------------------------------------------------------------------//
//--GETTERS Y SETTERS
  	public function GetId()
	{
		return $this->id;
	}
	public function GetPrecio()
	{
		return $this->precio;
	}
	public function GetLocal()
	{
		return $this->local;
	}
	public function GetLimite()
	{
		return $this->limite;
	}
	public function GetDesc()
	{
		return $this->desc;
	}
	public function SetId($valor)
	{
		$this->id = $valor;
	}
	public function SetPrecio($valor)
	{
		$this->precio = $valor;
	}
	public function SetLocal($valor)
	{
		$this->local = $valor;
	}
	public function SetLimite($valor)
	{
		$this->limite = $valor;
	}
	public function SetDesc($valor)
	{
		$this->desc = $valor;
	}
//--------------------------------------------------------------------------------//
//--CONSTRUCTOR
	public function __construct($dni=NULL)
	{
	}

	public static function TraerOp($usuario) 
	{	
		$objetoAccesoDato = AccesoDatos::dameUnObjetoAcceso(); 
		$consulta =$objetoAccesoDato->RetornarConsulta("select * from ofertas where id =:id");
		$consulta->bindValue(':id', $usuario->id, PDO::PARAM_INT);
		$consulta->execute();
		$arrPersonas= $consulta->fetchAll(PDO::FETCH_CLASS, "Ofertas");
		return $arrPersonas;					
	}

//--METODO DE CLAS
	public static function TraerTodasLasOfertas()
	{
		$objetoAccesoDato = AccesoDatos::dameUnObjetoAcceso(); 
		$consulta =$objetoAccesoDato->RetornarConsulta("select * from ofertas");
		$consulta->execute();			
		$arrPersonas= $consulta->fetchAll(PDO::FETCH_CLASS, "ofertas");	
		return $arrPersonas;
	}
	
	public static function ActualizarOferta($persona)
	{
			$objetoAccesoDato = AccesoDatos::dameUnObjetoAcceso(); 
			$consulta =$objetoAccesoDato->RetornarConsulta("
				update ofertas 
				set precio=:precio,
				local=:local,
				limite=:limite,
				descripcion=:descripcion
				WHERE id=:id");
			$consulta->bindValue(':id',$persona->id, PDO::PARAM_INT);
			$consulta->bindValue(':precio',$persona->precio, PDO::PARAM_STR);
			$consulta->bindValue(':local', $persona->local, PDO::PARAM_STR);
			$consulta->bindValue(':limite', $persona->limite, PDO::PARAM_STR);
			$consulta->bindValue(':descripcion', $persona->desc, PDO::PARAM_STR);
			return $consulta->execute();
	}
	public static function InsertarOferta($persona)
	{
		$objetoAccesoDato = AccesoDatos::dameUnObjetoAcceso(); 
		$consulta =$objetoAccesoDato->RetornarConsulta("INSERT into ofertas (precio,local,limite,descripcion)values(:precio,:local,:limite,:descripcion)");
		$consulta->bindValue(':precio',$persona->precio, PDO::PARAM_STR);
		$consulta->bindValue(':local', $persona->local, PDO::PARAM_STR);
		$consulta->bindValue(':limite', $persona->limite, PDO::PARAM_STR);
		$consulta->bindValue(':descripcion', $persona->desc, PDO::PARAM_STR);
		$consulta->execute();
		return $objetoAccesoDato->RetornarUltimoIdInsertado();
	}	
}