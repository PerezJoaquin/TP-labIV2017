<?php
require_once"AccesoDatos.php";
class Reserva
{
//--------------------------------------------------------------------------------//
//--ATRIBUTOS
	public $id;
	public $fecha;
 	public $userid;
  	public $desc;
	public $idlocal;
	public $estado;
//--------------------------------------------------------------------------------//
//--------------------------------------------------------------------------------//
//--GETTERS Y SETTERS
  	public function GetId()
	{
		return $this->id;
	}
	public function GetFecha()
	{
		return $this->fecha;
	}
	public function GetUserid()
	{
		return $this->userid;
	}
	public function GetDesc()
	{
		return $this->desc;
	}
	public function GetIdLocal()
	{
		return $this->idlocal;
	}
	public function SetId($valor)
	{
		$this->id = $valor;
	}
	public function SetFecha($valor)
	{
		$this->fecha = $valor;
	}
	public function SetUserid($valor)
	{
		$this->userid = $valor;
	}
	public function SetDesc($valor)
	{
		$this->desc = $valor;
	}
	public function SetIdLocal($valor)
	{
		$this->idlocal = $valor;
	}
//--------------------------------------------------------------------------------//
//--CONSTRUCTOR
	public function __construct($dni=NULL)
	{
	}
//--METODO DE CLASE
	public static function TraerReservas($usuario) 
	{	
		$objetoAccesoDato = AccesoDatos::dameUnObjetoAcceso(); 
		$consulta =$objetoAccesoDato->RetornarConsulta("select * from reservas where userid =:userid");
		$consulta->bindValue(':userid', $usuario->userid, PDO::PARAM_STR);
		$consulta->execute();
		$arrPersonas= $consulta->fetchAll(PDO::FETCH_CLASS, "reserva");
		return $arrPersonas;					
	}
	public static function InsertarReserva($persona)
	{
		$objetoAccesoDato = AccesoDatos::dameUnObjetoAcceso(); 
		$consulta =$objetoAccesoDato->RetornarConsulta("INSERT into reservas (fecha,userid,descripcion,idlocal,estado)values(:fecha,:userid,:descr,:idlocal,:estado)");
		$consulta->bindValue(':fecha',$persona->fecha, PDO::PARAM_STR);
		$consulta->bindValue(':userid', $persona->userid, PDO::PARAM_INT);
		$consulta->bindValue(':descr', $persona->desc, PDO::PARAM_STR);
		$consulta->bindValue(':idlocal', $persona->idlocal, PDO::PARAM_STR);
		$consulta->bindValue(':estado', 'Pendiente', PDO::PARAM_STR);
		$consulta->execute();
		return $objetoAccesoDato->RetornarUltimoIdInsertado();
	}	
}