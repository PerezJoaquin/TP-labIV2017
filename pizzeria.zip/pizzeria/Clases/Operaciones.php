<?php
require_once"AccesoDatos.php";
class Operacion
{
//--------------------------------------------------------------------------------//
//--ATRIBUTOS
	public $id;
	public $iditem;
 	public $userid;
	public $tipo;
	public $estado;
	public $fireid;
	public $latitud;
	public $longitud;
//--------------------------------------------------------------------------------//
//--------------------------------------------------------------------------------//
//--GETTERS Y SETTERS
  	public function GetId()
	{
		return $this->id;
	}
	public function GetIdItem()
	{
		return $this->iditem;
	}
	public function GetUserid()
	{
		return $this->userid;
	}
	public function GetTipo()
	{
		return $this->tipo;
	}
	public function GetEstado()
	{
		return $this->estado;
	}
	public function GetFire()
	{
		return $this->fireid;
	}
	public function GetLat()
	{
		return $this->latitud;
	}
	public function GetLong()
	{
		return $this->longitud;
	}
	public function SetId($valor)
	{
		$this->id = $valor;
	}
	public function SetIdItem($valor)
	{
		$this->iditem = $valor;
	}
	public function SetUserid($valor)
	{
		$this->userid = $valor;
	}
	public function SetTipo($valor)
	{
		$this->tipo = $valor;
	}
	public function SetEstado($valor)
	{
		$this->estado = $valor;
	}
	public function SetFire($valor)
	{
		$this->fireid = $valor;
	}
	public function SetLat($valor)
	{
		$this->latitud = $valor;
	}
	public function SetLong($valor)
	{
		$this->longitud = $valor;
	}

	public function __construct($dni=NULL){}

	public static function TraerOpOfer($usuario) 
	{	
		$objetoAccesoDato = AccesoDatos::dameUnObjetoAcceso(); 
		$consulta =$objetoAccesoDato->RetornarConsulta("select * from operaciones where userid =:userid AND tipo ='oferta'");
		$consulta->bindValue(':userid', $usuario->userid, PDO::PARAM_STR);
		$consulta->execute();
		$arrPersonas= $consulta->fetchAll(PDO::FETCH_CLASS, "Operacion");
		return $arrPersonas;					
	}
	public static function TraerOpProd($usuario) 
	{	
		$objetoAccesoDato = AccesoDatos::dameUnObjetoAcceso(); 
		$consulta =$objetoAccesoDato->RetornarConsulta("select * from operaciones where userid =:userid AND tipo ='producto'");
		$consulta->bindValue(':userid', $usuario->userid, PDO::PARAM_STR);
		$consulta->execute();
		$arrPersonas= $consulta->fetchAll(PDO::FETCH_CLASS, "Operacion");
		return $arrPersonas;					
	}
	public static function TraerTodas() 
	{
		$objetoAccesoDato = AccesoDatos::dameUnObjetoAcceso(); 
		$consulta =$objetoAccesoDato->RetornarConsulta("select * from operaciones");
		$consulta->execute();
		$arrPersonas= $consulta->fetchAll(PDO::FETCH_CLASS, "Operacion");
		return $arrPersonas;					
	}

	public static function InsertarOperacion($persona){
		$objetoAccesoDato = AccesoDatos::dameUnObjetoAcceso(); 
		$consulta =$objetoAccesoDato->RetornarConsulta("INSERT into operaciones (iditem,userid,estado,tipo,fireid,latitud,longitud)values(:iditem,:userid,:estado,:tipo,:fireid,:latitud,:longitud)");
		$consulta->bindValue(':iditem',$persona->iditem, PDO::PARAM_INT);
		$consulta->bindValue(':userid', $persona->userid, PDO::PARAM_INT);
		$consulta->bindValue(':tipo', $persona->tipo, PDO::PARAM_STR);
		$consulta->bindValue(':estado', $persona->estado, PDO::PARAM_STR);
		$consulta->bindValue(':fireid', $persona->fireid, PDO::PARAM_STR);
		$consulta->bindValue(':latitud', $persona->latitud, PDO::PARAM_STR);
		$consulta->bindValue(':longitud', $persona->longitud, PDO::PARAM_STR);
		$consulta->execute();
		return $objetoAccesoDato->RetornarUltimoIdInsertado();
	}	

	public static function ModificarOperacion($persona)
	{
		$objetoAccesoDato = AccesoDatos::dameUnObjetoAcceso(); 
		$consulta =$objetoAccesoDato->RetornarConsulta("
			update operaciones 
			set iditem =:iditem,
			userid=:userid,
			tipo=:tipo,
			estado=:estado,
			fireid=:fireid,
			latitud=:latitud,
			longitud=:longitud
			WHERE id=:id");
		$consulta->bindValue(':id',$persona->id, PDO::PARAM_INT);
		$consulta->bindValue(':iditem',$persona->iditem, PDO::PARAM_INT);
		$consulta->bindValue(':userid', $persona->userid, PDO::PARAM_INT);
		$consulta->bindValue(':tipo', $persona->tipo, PDO::PARAM_STR);
		$consulta->bindValue(':estado', $persona->estado, PDO::PARAM_STR);
		$consulta->bindValue(':fireid', $persona->fireid, PDO::PARAM_STR);
		$consulta->bindValue(':latitud', $persona->latitud, PDO::PARAM_STR);
		$consulta->bindValue(':longitud', $persona->longitud, PDO::PARAM_STR);
		return $consulta->execute();
	}
}