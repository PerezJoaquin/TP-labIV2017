<?php
require_once"AccesoDatos.php";
class Local
{
//--------------------------------------------------------------------------------//
//--ATRIBUTOS
	public $idlocal;
	public $nombre;
 	public $latitud;
  	public $longitud;
	public $direccion;
	public $imagen1;
	public $imagen2;
	public $imagen3;
//--------------------------------------------------------------------------------//
//--------------------------------------------------------------------------------//
//--GETTERS Y SETTERS
  	public function GetId()
	{
		return $this->idlocal;
	}
	public function GetNombre()
	{
		return $this->nombre;
	}
	public function GetLatitud()
	{
		return $this->latitud;
	}
	public function GetLongitud()
	{
		return $this->longitud;
	}
	public function GetDireccion()
	{
		return $this->direccion;
	}
	public function GetImagen1()
	{
		return $this->imagen1;
	}
	public function GetImagen2()
	{
		return $this->imagen2;
	}
	public function GetImagen3()
	{
		return $this->imagen3;
	}
	
	public function SetId($valor)
	{
		$this->idlocal = $valor;
	}
	public function SetNombre($valor)
	{
		$this->nombre = $valor;
	}
	public function SetLatitud($valor)
	{
		$this->latitud = $valor;
	}
	public function SetLongitud($valor)
	{
		$this->longitud = $valor;
	}
	public function SetDireccion($valor)
	{
		$this->direccion = $valor;
	}
	public function SetImagen1($valor)
	{
		$this->imagen1 = $valor;
	}
	public function SetImagen2($valor)
	{
		$this->imagen2 = $valor;
	}
	public function SetImagen3($valor)
	{
		$this->imagen3 = $valor;
	}
//--------------------------------------------------------------------------------//
//--CONSTRUCTOR
	public function __construct($dni=NULL)
	{
	}

//--METODO DE CLASE
	public static function TraerLocales()
	{
		$objetoAccesoDato = AccesoDatos::dameUnObjetoAcceso(); 
		$consulta =$objetoAccesoDato->RetornarConsulta("select * from locales");
		$consulta->execute();			
		$arrPersonas= $consulta->fetchAll(PDO::FETCH_CLASS, "Local");	
		return $arrPersonas;
	}
	
	public static function ActualizarLocal($persona)
	{
			$objetoAccesoDato = AccesoDatos::dameUnObjetoAcceso(); 
			$consulta =$objetoAccesoDato->RetornarConsulta("update locales set nombre=:nombre,direccion=:direccion,
				imagen1=:imagen1,
				imagen2=:imagen2,
				imagen3=:imagen3,
				latitud=:latitud,
				longitud=:longitud
				WHERE idlocal=:id");
			$consulta->bindValue(':id',$persona->idlocal, PDO::PARAM_INT);
			$consulta->bindValue(':nombre',$persona->nombre, PDO::PARAM_STR);
			$consulta->bindValue(':latitud',$persona->latitud, PDO::PARAM_STR);
			$consulta->bindValue(':longitud',$persona->longitud, PDO::PARAM_STR);
			$consulta->bindValue(':direccion', $persona->direccion, PDO::PARAM_STR);
			$consulta->bindValue(':imagen1', $persona->imagen1, PDO::PARAM_STR);
			$consulta->bindValue(':imagen2', $persona->imagen2, PDO::PARAM_STR);
			$consulta->bindValue(':imagen3', $persona->imagen3, PDO::PARAM_STR);
			return $consulta->execute();
	}
	public static function InsertarLocal($persona)
	{
		$objetoAccesoDato = AccesoDatos::dameUnObjetoAcceso(); 
		$consulta =$objetoAccesoDato->RetornarConsulta("INSERT into locales (nombre,direccion,latitud,longitud,imagen1,imagen2,imagen3)
														values(:nombre,:direccion,:latitud,:longitud,:imagen1,:imagen2,:imagen3)");
		//$consulta =$objetoAccesoDato->RetornarConsulta("CALL InsertarPersona (:nombre,:apellido,:dni)");
		$consulta->bindValue(':nombre',$persona->nombre, PDO::PARAM_STR);
		$consulta->bindValue(':direccion', $persona->direccion, PDO::PARAM_STR);
		$consulta->bindValue(':latitud', $persona->latitud, PDO::PARAM_STR);
		$consulta->bindValue(':longitud', $persona->longitud, PDO::PARAM_STR);
		$consulta->bindValue(':imagen1', $persona->imagen1, PDO::PARAM_STR);
		$consulta->bindValue(':imagen2', $persona->imagen2, PDO::PARAM_STR);
		$consulta->bindValue(':imagen3', $persona->imagen3, PDO::PARAM_STR);
		$consulta->execute();
		return $objetoAccesoDato->RetornarUltimoIdInsertado();
	}	
}