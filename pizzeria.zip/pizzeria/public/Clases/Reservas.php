<?php
require_once"AccesoDatos.php";
class Reserva
{
//--------------------------------------------------------------------------------//
//--ATRIBUTOS
	public $id;
	public $fecha;
 	public $userid;
  	public $desc;
	public $idlocal;
	public $estado;
	/*public $foto;
	public $sexo;
	public $password;*/
//--------------------------------------------------------------------------------//
//--------------------------------------------------------------------------------//
//--GETTERS Y SETTERS
  	public function GetId()
	{
		return $this->id;
	}
	public function GetFecha()
	{
		return $this->fecha;
	}
	public function GetUserid()
	{
		return $this->userid;
	}
	public function GetDesc()
	{
		return $this->desc;
	}
	public function GetIdLocal()
	{
		return $this->idlocal;
	}/*
	public function GetSexo()
	{
		return $this->sexo;
	}
	public function GetPassword()
	{
		return $this->password;
	}*/
	public function SetId($valor)
	{
		$this->id = $valor;
	}
	public function SetFecha($valor)
	{
		$this->fecha = $valor;
	}
	public function SetUserid($valor)
	{
		$this->userid = $valor;
	}
	public function SetDesc($valor)
	{
		$this->desc = $valor;
	}
	public function SetIdLocal($valor)
	{
		$this->idlocal = $valor;
	}
	/*public function SetSexo($valor)
	{
		$this->sexo = $valor;
	}
	public function SetPassword($valor)
	{
		$this->password = $valor;
	}*/
//--------------------------------------------------------------------------------//
//--CONSTRUCTOR
	public function __construct($dni=NULL)
	{
		/*if($dni != NULL){
			$obj = Usuario::TraerUnaPersona($dni);
			
			$this->apellido = $obj->apellido;
			$this->nombre = $obj->nombre;
			$this->dni = $dni;
			$this->foto = $obj->foto;
			$this->sexo = $obj->sexo;
			$this->password = $password;
		}*/
	}

//--TOSTRING	
  	/*public function ToString()
	{
	  	return $this->apellido."-".$this->nombre."-".$this->dni."-".$this->foto."-".$this->sexo."-".$this->password;
	}*/

//--METODO DE CLASE
	public static function TraerReservas($usuario) 
	{	
		$objetoAccesoDato = AccesoDatos::dameUnObjetoAcceso(); 
		$consulta =$objetoAccesoDato->RetornarConsulta("select * from reservas where userid =:userid");
		//$consulta =$objetoAccesoDato->RetornarConsulta("CALL TraerUnaPersona(:id)");
		$consulta->bindValue(':userid', $usuario->userid, PDO::PARAM_STR);
		$consulta->execute();
		$arrPersonas= $consulta->fetchAll(PDO::FETCH_CLASS, "reserva");
		return $arrPersonas;					
	}
/*
	public static function login(/*$userParametro, $contraParametro* $usuario) 
	{	
		$objetoAccesoDato = AccesoDatos::dameUnObjetoAcceso(); 
		$consulta =$objetoAccesoDato->RetornarConsulta("select * from usuarios where usuario =:usuario and contrasena =:contrasena");
		$consulta->bindValue(':usuario', $usuario->usuario, PDO::PARAM_STR);
		$consulta->bindValue(':contrasena', $usuario->contrasena, PDO::PARAM_STR);
		$consulta->execute();
		$personaBuscada= $consulta->fetchObject('usuario');
		return $personaBuscada;					
	}
	
	public static function TraerTodasLasPersonas()
	{
		$objetoAccesoDato = AccesoDatos::dameUnObjetoAcceso(); 
		$consulta =$objetoAccesoDato->RetornarConsulta("select * from persona");
		//$consulta =$objetoAccesoDato->RetornarConsulta("CALL TraerTodasLasPersonas() ");
		$consulta->execute();			
		$arrPersonas= $consulta->fetchAll(PDO::FETCH_CLASS, "persona");	
		return $arrPersonas;
	}
	
	public static function BorrarPersona($idParametro)
	{	
		$objetoAccesoDato = AccesoDatos::dameUnObjetoAcceso(); 
		$consulta =$objetoAccesoDato->RetornarConsulta("delete from persona	WHERE id=:id");	
		//$consulta =$objetoAccesoDato->RetornarConsulta("CALL BorrarPersona(:id)");	
		$consulta->bindValue(':id',$idParametro, PDO::PARAM_INT);		
		$consulta->execute();
		return $consulta->rowCount();
		
	}
	
	public static function ModificarPersona($persona)
	{
			$objetoAccesoDato = AccesoDatos::dameUnObjetoAcceso(); 
			$consulta =$objetoAccesoDato->RetornarConsulta("
				update persona 
				set nombre=:nombre,
				apellido=:apellido,
				foto=:foto,
				sexo=:sexo,
				password=:password
				WHERE id=:id");
			//$objetoAccesoDato = AccesoDatos::dameUnObjetoAcceso(); 
			//$consulta =$objetoAccesoDato->RetornarConsulta("CALL ModificarPersona(:id,:nombre,:apellido)");
			$consulta->bindValue(':id',$persona->id, PDO::PARAM_INT);
			$consulta->bindValue(':nombre',$persona->nombre, PDO::PARAM_STR);
			$consulta->bindValue(':apellido', $persona->apellido, PDO::PARAM_STR);
			$consulta->bindValue(':foto', $persona->foto, PDO::PARAM_STR);
			$consulta->bindValue(':sexo', $persona->sexo, PDO::PARAM_STR);
			$consulta->bindValue(':password', $persona->password, PDO::PARAM_STR);
			return $consulta->execute();
	}*/
//--------------------------------------------------------------------------------//
//--------------------------------------------------------------------------------//
	public static function InsertarReserva($persona)
	{
		$objetoAccesoDato = AccesoDatos::dameUnObjetoAcceso(); 
		$consulta =$objetoAccesoDato->RetornarConsulta("INSERT into reservas (fecha,userid,descripcion,idlocal,estado)values(:fecha,:userid,:descr,:idlocal,:estado)");
		//$consulta =$objetoAccesoDato->RetornarConsulta("CALL InsertarPersona (:nombre,:apellido,:dni)");
		$consulta->bindValue(':fecha',$persona->fecha, PDO::PARAM_STR);
		$consulta->bindValue(':userid', $persona->userid, PDO::PARAM_INT);
		$consulta->bindValue(':descr', $persona->desc, PDO::PARAM_STR);
		$consulta->bindValue(':idlocal', $persona->idlocal, PDO::PARAM_STR);
		$consulta->bindValue(':estado', 'Pendiente', PDO::PARAM_STR);
		//$consulta->bindValue(':local', $persona->local, PDO::PARAM_STR);
		$consulta->execute();
		return $objetoAccesoDato->RetornarUltimoIdInsertado();
	}	
}