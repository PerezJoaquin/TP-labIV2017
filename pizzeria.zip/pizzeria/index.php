<?php
    use \Psr\Http\Message\ServerRequestInterface as Request;
    use \Psr\Http\Message\ResponseInterface as Response;

    require 'Clases/vendor/autoload.php';
    require 'Clases/Personas.php';
    require 'Clases/Ofertas.php';
    require 'Clases/Reservas.php';
    require 'Clases/Locales.php';
    require 'Clases/Operaciones.php';
    require 'Clases/Productos.php';

    $app = new \Slim\App;


    $app->get('/login', function ($req, $res) {
        $perConst = new Usuario();
        $perConst->SetUsuario($req->getParam('usuario'));
        $perConst->SetContra($req->getParam('contrasena')); 
        return $res
           ->withHeader('Content-type', 'application/json')
           ->getBody()
           ->write(
            json_encode(
                Usuario::login($perConst)
            )
        );
    });
    $app->get('/usuarios', function ($req, $res) {       
        return $res
           ->withHeader('Content-type', 'application/json')
           ->getBody()
           ->write(
            json_encode(
                Usuario::TraerTodos()
            )
        );
    });
    $app->get('/registrar', function ($req, $res) {
        $perConst = new Usuario();
        $perConst->SetUsuario($req->getParam('usuario'));
        $perConst->SetContra($req->getParam('contrasena'));
        $perConst->SetTipo($req->getParam('tipo'));
        $perConst->SetLocal($req->getParam('local'));
        
        return $res
           ->withHeader('Content-type', 'application/json')
           ->getBody()
           ->write(
            json_encode(
                Usuario::InsertarPersona($perConst)
            )
        );
    });
    $app->get('/estado', function ($req, $res) {
        $perConst = new Usuario();
        $perConst->SetId($req->getParam('id'));
        $perConst->SetEstado($req->getParam('estado'));
        return $res
           ->withHeader('Content-type', 'application/json')
           ->getBody()
           ->write(
            json_encode(
                Usuario::ActualizarEstado($perConst)
            )
        );
    });
    $app->post('/usermod', function ($req, $res) {
        $perConst = new Usuario();
        $perConst->SetId($req->getParam('id'));
        $perConst->SetUsuario($req->getParam('usuario'));
        $perConst->SetContra($req->getParam('contrasena'));
        $perConst->SetTipo($req->getParam('tipo'));
        $perConst->SetLocal($req->getParam('local'));
        $perConst->SetEstado($req->getParam('estado'));
        return $res
           ->withHeader('Content-type', 'application/json')
           ->getBody()
           ->write(
            json_encode(
                Usuario::ActualizarUsuario($perConst)
            )
        );
    });





    $app->get('/ofertas', function ($req, $res, $args) {
        
        return $res
           ->withHeader('Content-type', 'application/json')
           ->getBody()
           ->write(
            json_encode(
                Ofertas::TraerTodasLasOfertas()
            )
        );        
    });
    $app->post('/oferta', function ($req, $res) {
        $perConst = new Ofertas();
        $perConst->SetId($req->getParam('id'));
        return $res
           ->withHeader('Content-type', 'application/json')
           ->getBody()
           ->write(
            json_encode(
                Ofertas::TraerOp($perConst)
            )
        );
    });
    $app->post('/guardarof', function ($req, $res) {
        $perConst = new Ofertas();
        $perConst->SetPrecio($req->getParam('precio'));
        $perConst->SetLocal($req->getParam('local'));
        $perConst->SetLimite($req->getParam('limite'));
        $perConst->SetDesc($req->getParam('descripcion'));
        return $res
           ->withHeader('Content-type', 'application/json')
           ->getBody()
           ->write(
            json_encode(
                Ofertas::InsertarOferta($perConst)
            )
        );
    });
    $app->post('/ofermod', function ($req, $res) {
        $perConst = new Ofertas();
        $perConst->SetId($req->getParam('id'));
        $perConst->SetDesc($req->getParam('descripcion'));
        $perConst->SetPrecio($req->getParam('precio'));
        $perConst->SetLocal($req->getParam('local'));
        $perConst->SetLimite($req->getParam('limite'));
        return $res
           ->withHeader('Content-type', 'application/json')
           ->getBody()
           ->write(
            json_encode(
                Ofertas::ActualizarOferta($perConst)
            )
        );
    });





    $app->post('/reservar', function ($req, $res) {
        $perConst = new Reserva();
        $perConst->SetFecha($req->getParam('fecha'));
        $perConst->SetUserid($req->getParam('userid'));
        $perConst->SetDesc($req->getParam('descripcion'));
        $perConst->SetIdLocal($req->getParam('idlocal'));
        
        return $res
           ->withHeader('Content-type', 'application/json')
           ->getBody()
           ->write(
            json_encode(
                Reserva::InsertarReserva($perConst)
            )
        );
    });
    $app->post('/reservas', function ($req, $res) {
        $perConst = new Reserva();
        $perConst->SetUserid($req->getParam('userid'));
        return $res
           ->withHeader('Content-type', 'application/json')
           ->getBody()
           ->write(
            json_encode(
                Reserva::TraerReservas($perConst)
            )
        );
    });





    $app->get('/locales', function ($req, $res) {
        return $res
           ->withHeader('Content-type', 'application/json')
           ->getBody()
           ->write(
            json_encode(
                Local::TraerLocales()
            )
        );
    });
    $app->post('/localmod', function ($req, $res) {
        $perConst = new Local();
        $perConst->SetId($req->getParam('id'));
        $perConst->SetNombre($req->getParam('nombre'));
        $perConst->SetLatitud($req->getParam('latitud'));
        $perConst->SetLongitud($req->getParam('longitud'));
        $perConst->SetDireccion($req->getParam('direccion'));
        $perConst->SetImagen1($req->getParam('imagen1'));
        $perConst->SetImagen2($req->getParam('imagen2'));
        $perConst->SetImagen3($req->getParam('imagen3'));
        return $res
           ->withHeader('Content-type', 'application/json')
           ->getBody()
           ->write(
            json_encode(
                Local::ActualizarLocal($perConst)
            )
        );
    });
    $app->post('/guardarlocal', function ($req, $res) {
        $perConst = new Local();
        $perConst->SetNombre($req->getParam('nombre'));
        $perConst->SetDireccion($req->getParam('direccion'));
        $perConst->SetLatitud($req->getParam('latitud'));
        $perConst->SetLongitud($req->getParam('longitud'));
        $perConst->SetImagen1($req->getParam('img1'));
        $perConst->SetImagen2($req->getParam('img2'));
        $perConst->SetImagen3($req->getParam('img3'));
        return $res
           ->withHeader('Content-type', 'application/json')
           ->getBody()
           ->write(
            json_encode(
                Local::InsertarLocal($perConst)
            )
        );
    });





    $app->post('/opofer', function ($req, $res) {
        $perConst = new Operacion();
        $perConst->SetUserid($req->getParam('userid'));
        return $res
           ->withHeader('Content-type', 'application/json')
           ->getBody()
           ->write(
            json_encode(
                Operacion::TraerOpOfer($perConst)
            )
        );
    });
    $app->post('/opprod', function ($req, $res) {
        $perConst = new Operacion();
        $perConst->SetUserid($req->getParam('userid'));
        return $res
           ->withHeader('Content-type', 'application/json')
           ->getBody()
           ->write(
            json_encode(
                Operacion::TraerOpProd($perConst)
            )
        );
    });
    $app->post('/operaciones', function ($req, $res) {
        return $res
           ->withHeader('Content-type', 'application/json')
           ->getBody()
           ->write(
            json_encode(
                Operacion::TraerTodas()
            )
        );
    });
    $app->post('/guardarop', function ($req, $res) {
        $perConst = new Operacion();
        $perConst->SetIdItem($req->getParam('iditem'));
        $perConst->SetUserid($req->getParam('userid'));
        $perConst->SetTipo($req->getParam('tipo'));
        $perConst->SetFire($req->getParam('fireid'));
        $perConst->SetLat($req->getParam('lat'));
        $perConst->SetLong($req->getParam('long'));
        $perConst->SetEstado('Pendiente');
        return $res
           ->withHeader('Content-type', 'application/json')
           ->getBody()
           ->write(
            json_encode(
                Operacion::InsertarOperacion($perConst)
            )
        );
    });
    $app->post('/modop', function ($req, $res) {
        $perConst = new Operacion();
        $perConst->SetId($req->getParam('id'));
        $perConst->SetIdItem($req->getParam('iditem'));
        $perConst->SetUserid($req->getParam('userid'));
        $perConst->SetTipo($req->getParam('tipo'));
        $perConst->SetFire($req->getParam('fireid'));
        $perConst->SetLat($req->getParam('lat'));
        $perConst->SetLong($req->getParam('long'));
        $perConst->SetEstado($req->getParam('estado'));
        return $res
           ->withHeader('Content-type', 'application/json')
           ->getBody()
           ->write(
            json_encode(
                Operacion::ModificarOperacion($perConst)
            )
        );
    });





    $app->get('/productos', function ($req, $res) {
        return $res
           ->withHeader('Content-type', 'application/json')
           ->getBody()
           ->write(
            json_encode(
                Producto::TraerProductos()
            )
        );
    });
    $app->post('/guardaprod', function ($req, $res) {
        $perConst = new Producto();
        $perConst->SetNombre($req->getParam('nombre'));
        $perConst->SetPrecio($req->getParam('precio'));
        $perConst->SetImagen($req->getParam('imagen'));
        return $res
           ->withHeader('Content-type', 'application/json')
           ->getBody()
           ->write(
            json_encode(
                Producto::InsertarProducto($perConst)
            )
        );
    });
    $app->post('/prodmod', function ($req, $res) {
        $perConst = new Producto();
        $perConst->SetId($req->getParam('id'));
        $perConst->SetNombre($req->getParam('nombre'));
        $perConst->SetPrecio($req->getParam('precio'));
        $perConst->SetImagen($req->getParam('imagen'));
        return $res
           ->withHeader('Content-type', 'application/json')
           ->getBody()
           ->write(
            json_encode(
                Producto::ActualizarProducto($perConst)
            )
        );
    });
    
    $app->add(function ($req, $res, $next) {
        $response = $next($req, $res);
        return $response
                ->withHeader('Access-Control-Allow-Origin', '*')
                ->withHeader('Access-Control-Allow-Headers', 'X-Requested-With, Content-Type, Accept, Origin, Authorization')
                ->withHeader('Access-Control-Allow-Methods', 'GET, POST, PUT, DELETE, OPTIONS');
    });

    $app->run();